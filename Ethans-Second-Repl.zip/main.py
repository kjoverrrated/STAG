'''
~------------STAG RAILROAD V0------------~
~------------By Ethan Ericson------------~
'''
import pygame, sys
from pygame.locals import QUIT
from setup import images, locations, colors

#~---------Screen Setup---------~

#Defining the orgin
orgin = (0,0)
#Define the size of the screen
size = (400, 300)

#Define the display surface
DISPLAYSURF = pygame.display.set_mode((size))

#The caption title
pygame.display.set_caption("STAG")

#~---------Location and Enemy Setup---------~

def encounterSetup(i, li, x, y, rx, ry ):

  #~---------Loading the Background---------~
  
  #Define the location load function
  loc = pygame.image.load("Locations/" + locations[li])

  #Fitting the location to the screen 
  loc = pygame.transform.scale(loc, (400,150))

  #Getting the bounding rectangle of the location
  locRect = loc.get_rect()

  #Moving the location
  locRect = locRect.move(0,30)
  
  #Loading the background onto the display surface
  DISPLAYSURF.blit(loc,locRect)
  
#~---------Loading the Enemy---------~
  
  #Define the image load function
  image = pygame.image.load("Enemies/" + images[i])

  #Fitting the image to the screen
  image = pygame.transform.scale(image, (x,y))

  #Getting the bounding rectangle of the image 
  rect = image.get_rect()

  #Moving the image
  rect = rect.move((rx,ry))

  #Loading the Image onto the display surface
  DISPLAYSURF.blit(image, (rect))

#~---------THE PROGRAM BEGINS---------~

#Start the program
pygame.init()

while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

#Calling the encounter function
    encounterSetup(2, 2, 200, 150, 100, 30)
  
#Setting the Frame Rate
    pygame.display.update()






    
   
    

  


pygame.quit()