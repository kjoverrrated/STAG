#Enemy images
images = ["RockoTheRat_img.png", "SamTheSlime_img.png", "Wolf_img.png", "DarkDeer_img.png", "VampireChicken_img.png", "KingChicken_img.jpg", "VicousVampire_img.jpg", "Werewolf_img.jpg", "VampireBats_img.jpg", "Vampire_img.jpg", "ConductorCoyote_img.jpg"]

#Locations
locations = ["JonesCenterPool_loc.jpg", "JonesCenterIceskate_loc.jpg", "JonesCenterTract_loc.jpg", "JonesCenterEntrance_loc.png", "TysonStore_loc.png", "LutherGeorgePark_loc.jpg"]

#Define some colors 
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

#Organizing the colors
colors = (BLACK, WHITE, RED, GREEN, BLUE)






