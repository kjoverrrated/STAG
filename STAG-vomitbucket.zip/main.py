
## LOWERCASE. ALL UI WILL BE CONVERTED TO LOWERCASE. 

##fix punctuation errors !!!!

# user input: reading tone
posUI = ['yes','y','yeah', 'ye', 'sure', 'okay', 'ok', 'k', 'yea', 'yay']
negUI = ['no', 'n', 'nope', 'nah', 'nay']
rudeUI = ['gross', 'ew']


dirL = ['left', 'l']
dirR = ['right', 'r']
dirU = ['up', 'upwards', 'forwards', 'forward', 'upward', 'onwards', 'onward', 'continue', 'straight']
dirB = ['nevermind', 'back', 'backward', 'backwards', 'turn around']

dirPrompt = [dirL, dirR, dirU, dirB]

## STAG output: responding
toRude = ['Watch it.']

# see dirPrompt to base all out on any in from that folder.
toDir = ['Good idea.', 'Are you sure? Alright.', 'Headed that way.', 'You are going that way.']


## IDLE CYCLES
# depletes the phrase once used.
# once all phrases in a cycle are used, the cycle changes. 
# defaults back to '...?' upon all cycle usage.

#cycle 1 of minutes taken without action
idle1 = ['The great deer massacre of 2009. Ever hear about it? Hunting state, this is. I am shivering just remembering. I lost so many that morning...', 'Tyson Foods is rather good at keeping the chickens out of deer country.', 'Careful visiting Arkansas in autumn. Gets real loud up in the mountains.']

#cycle 2
idle2 = ['I knew that shift in the grass was unnatural. I should have bolted right then. Only, they were in the sky. We were never safe.', 'I was talking about Bikes Blues and Barbeques. That is why the mountains get so loud.', 'Howdy Yawl! Hehe, thought I would give it a try.']

#cycle 3
idle3 = ['Are you confused?', 'Try taking action.', 'You know how to take action, right?', 'If you are stuck, go back.', 'I do not think there is anyone here.', 'There is nothing here.', 'Should I... alert someone?', 'Still nothing.', 'Wait! Hear that?!... ... ...it is still nothing.', 'What is it that Einstein said again?']

##testing purposes
ui = input('>> ')
ui = str(ui.lower())


if ui in posUI:
  print('positive')
elif ui in negUI:
  print('negative')
else:
  print('unidentifiable.')